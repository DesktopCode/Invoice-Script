<?php
include "header.php";

if (isset($_POST['save'])) {
    $sitename    = $_POST['sitename'];
    $description = $_POST['description'];
    $keywords = $_POST['keywords']; 
    $email = $_POST['email'];
    $edit        = "UPDATE settings SET sitename='$sitename', description='$description', keywords='$keywords', email='$email'";
    $sql         = mysqli_query($connect, $edit);
}
if($sql):
$msg="Settings Updated";

endif;
?>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
        </ol>
      </div>

      <div class="row">
         
        <div class="col-md-9 column" style="margin-left:300px;">
            <div class="box">
              <h4 class="box-header round-top">Settings</h4>         
              <div class="box-container-toggle">
                  <div class="box-content">
<?php if($delmsg){ ?>
<div class="alert alert-danger" role="alert">
<strong> <?php echo htmlentities($delmsg);?></strong></div>
<?} ?>
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong> <?php echo htmlentities($msg);?></strong></div>
<?php } ?>
<?php
$sql    = "SELECT * FROM settings";
$result = mysqli_query($connect, $sql);
while ($s = mysqli_fetch_assoc($result)) {
?>
                                <center><form action="" method="post">
								<p>
									<label>Site Name</label>
									<input class="form-control" name="sitename" value="<?php
    echo $s['sitename'];
?>" type="text" required>
								</p><br />
								<p>
									<label>Description</label>
									<textarea class="form-control" name="description" required><?php
    echo $s['description'];
?></textarea>
								</p><br />
<p>
									<label>Keywords/Meta Tags</label>
									<input class="form-control" name="keywords" value="<?php
    echo $s['keywords'];
?>" type="text" required>
</p><br />
<p>
									<label>Currency Symbol</label>
									<input class="form-control" name="email" value="<?php
    echo $s['email'];
?>" type="text" required>
</p><br />
								<div class="form-actions">
                                    <input type="submit" name="save" class="btn btn-primary btn-block" value="Save Changes" />
                                </div>
								</form>

<br><br>
<div class="row">
<div class="col-sm-12">
 <div class="card-box">
<h4 class="m-b-30 m-t-0 header-title"><b>Invoice Header</b></h4>
<img class="img-responsive" src="../images/<?php echo htmlentities($s['headerimg']);?>" width="100%" height="100%"/>
<br />
<a href="change-header.php?id=1" class="btn btn-primary">Update Image</a>
</div>
</div>
</div>
<?php
}
?></center>                               
                  </div>
              </div>
            </div>
        </div>
      </div>

    </div>
  </div>

<?php
include "footer.php";
?>