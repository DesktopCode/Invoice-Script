<?php
include 'includes/config.php';

session_start();

if (isset($_SESSION['sec-username'])) {
    $uname = $_SESSION['sec-username'];
    $suser = mysqli_query($connect, "SELECT * FROM `users` WHERE username='$uname'");
    $count = mysqli_num_rows($suser);
    if ($count < 0) {
        echo '<meta http-equiv="refresh" content="0; url=index.php" />';
        exit;
    }
} else {
    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
    exit;
}

if (basename($_SERVER['SCRIPT_NAME']) != 'add_post.php' && basename($_SERVER['SCRIPT_NAME']) != 'posts.php' && basename($_SERVER['SCRIPT_NAME']) != 'add_page.php' && basename($_SERVER['SCRIPT_NAME']) != 'pages.php' && basename($_SERVER['SCRIPT_NAME']) != 'add_widget.php' && basename($_SERVER['SCRIPT_NAME']) != 'widgets.php' && basename($_SERVER['SCRIPT_NAME']) != 'add_ad.php' && basename($_SERVER['SCRIPT_NAME']) != 'ads.php') {
    $_GET  = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
    $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
}

function short_text($text, $length)
{
    $maxTextLenght = $length;
    $aspace        = " ";
    if (strlen($text) > $maxTextLenght) {
        $text = substr(trim($text), 0, $maxTextLenght);
        $text = substr($text, 0, strlen($text) - strpos(strrev($text), $aspace));
        $text = $text . '...';
    }
    return $text;
}

function byte_convert($size)
{
    if ($size < 1024)
        return $size . ' Byte';
    if ($size < 1048576)
        return sprintf("%4.2f KB", $size / 1024);
    if ($size < 1073741824)
        return sprintf("%4.2f MB", $size / 1048576);
    if ($size < 1099511627776)
        return sprintf("%4.2f GB", $size / 1073741824);
    else
        return sprintf("%4.2f TB", $size / 1073741824);
}

$sitename1 = mysqli_query($connect, "SELECT * FROM `settings` WHERE id='1'");
$settings = mysqli_fetch_assoc($sitename1);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Admin Panel - Dashboard</title>
       <meta content="" name="admin,gaming,clan,website,template,fuse,panel,controlled,control,fps,games,online,free">

    <!-- Bootstrap -->
    
    <link href="assets/css/styles.css" rel="stylesheet" />

	<!-- Font Awesome -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
	
	<!--DataTables-->
    <link href="assets/plugins/datatables/datatables.min.css" rel="stylesheet">
	
	<!-- jQuery --> 
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	
	<!-- CK Editor -->
	<script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script><!DOCTYPE html>

   
  <!-- Favicons -->
   <link rel="icon" type="image/png" href="assets/images/desktopcode-logo.png">
   <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php echo $rowfont['FontURL'];?>
    <style>
    html *
    {
    font-family:<?php echo $rowfont['FontName'];?>;
    }
    </style>


        <!-- CSS Files -->
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/style.css" rel="stylesheet">
        <script src="assets/js/modernizr.min.js"></script>

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">


</head>
	
<body>



<div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                          <ul>
                                <br><li class="menu-title">MENU</li>
                                <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                                </li>
                                <li class="has_sub">
                                <a href="settings.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Settings </span> </a>
                                </li>
                                <li class="has_sub">
                                <a href="users.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Admins </span> </a>
                                </li>
   <li class="has_sub">
                                <a href="add_wage.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Add Invoice </span> </a>
                                </li>
   <li class="has_sub">
                                <a href="wageslips.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Invoices </span> </a>
                                </li>  

   <li class="has_sub">
                                <a href="employees.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Employees </span> </a>
                                </li>       
  



                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

               
                </div>
                <!-- Sidebar -left -->

            </div>