<?php
include "header.php";

if(isset($_POST['update']))
{
$imgfile=$_FILES["postimage"]["name"];
// get the image extension
$extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));
// allowed extensions
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
// Validation for allowed extensions .in_array() function searches an array for a specific value.
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
//rename the image file
$imgnewfile=md5($imgfile).$extension;
// Code for move image into directory
move_uploaded_file($_FILES["postimage"]["tmp_name"],"../images/".$imgnewfile);



$logoid=intval($_GET['id']);
$query=mysqli_query($connect,"update settings SET headerimg='$imgnewfile' where id='1'");
if($query)
{
$msg="Image Updated!";
}
else{
$error="Something Went Wrong! Please Try Again!";    
} 
}
}
?>


<div class="col-lg-5" style="margin-left:400px;margin-top:30px;"">
<?php if($msg){ ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<center><strong><?php echo htmlentities($msg);?></strong></center>
<button type="button" class="btn-close btn-close-black" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>
</div>
<center>
<div class="col-lg-5">
<?php if($error){ ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
<strong><?php echo htmlentities($error);?></strong> 
<button type="button" class="btn-close btn-close-black" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>
</center>
</div> 



<form name="addpost" method="post" enctype="multipart/form-data">
<?php
$logoid=intval($_GET['id']);
$query=mysqli_query($connect,"select headerimg from settings where id='1'");
while($row=mysqli_fetch_array($query))
{
?>
                        <div>
                            <div>
                                <div class="col-lg-12" style="margin-top:200px;margin-left:-350px;">
                                    <div class=""><center>
                                        <form name="addpost" method="post">

 <div class="col-lg-12">
<h4 class="m-b-30 m-t-0 header-title"><b>Current Header Image</b></h4>
<img src="../images/<?php echo htmlentities($row['headerimg']);?>" style="width:50%; height:50%;"/>
<br />

</div>

<br><br><br>
<?php } ?>
<div class="col-lg-12">
<h4 class="m-b-30 m-t-0 header-title"><b>New Header Image</b></h4>
<input type="file" class="form-control" id="postimage" name="postimage" style="width:20%;" required>
</div>

<br>
<button type="submit" name="update" class="btn btn-success">Update</button>
</form>
                                    </div>
                                </div> <!-- end p-20 -->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->



                    </div> <!-- container -->

                </div> <!-- content -->

            </div>




 

    </body>
</html>
