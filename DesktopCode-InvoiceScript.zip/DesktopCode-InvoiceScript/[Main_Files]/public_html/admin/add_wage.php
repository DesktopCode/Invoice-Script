<?php
include "header.php";
?>
<style>
#cat_id {
color:black;
}
</style>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
        </ol>
      </div>  

      <div class="row">
        
       <div class="col-md-9 column" style="margin-left:300px;">
            <div class="box">
              <h4 class="box-header round-top">Add Invoice</h4>         
              <div class="box-container-toggle">
                  <div class="box-content">
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong> <?php echo htmlentities($msg);?></strong></div>
<?php } ?>
                                <center><form action="" method="post">
								<p>
									<label>Gross Amount</label>
									<input class="form-control" name="title" value="" type="text" style="width:20%;">
								</p><br />	
	<p>
									<label>Date</label>
									<input class="form-control" name="date2" value="" type="text" style="width:20%;">
								</p><br />
						
	<p>
									<label>National Insurance %</label>
									<input class="form-control" name="title2" value="" type="text" style="width:20%;">
								</p><br />
	<p>
									<label>Income Tax %</label>
									<input class="form-control" name="content" value="" type="text" style="width:20%;">
								</p><br />
	<p>
									<label>Free Allowance</label>
									<input class="form-control" name="content2" value="0" type="text" style="width:20%;">
								</p><br />	
								<p>
									<label>Employee</label><br />
									<select name="category_id">
									<?php
$crun = mysqli_query($connect, "SELECT * FROM `categories`");
while ($rw = mysqli_fetch_assoc($crun)) {
    echo '
                                    <option value="' . $rw['id'] . '">' . $rw['category'] . '</option>
									';
}
?>
                                    </select>
								</p><br />
								
							
								<div class="form-actions">
                                    <input type="submit" name="add" class="btn btn-primary" value="Add" />
								
                                </div>
								</form>

<?php
if (isset($_POST['add'])) {
    $title       = $_POST['title'];
    $title2       = $_POST['title2'];
    $code       = $_POST['content'];
    $code2       = $_POST['content2'];
    $date2       = $_POST['date2'];
    $category_id = $_POST['category_id'];
$random_number = intval( "0" . rand(1,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) );
    $add = "INSERT INTO posts (category_id, title, title2, content, content2, date) VALUES ('$category_id', '$title', '$title2', '$code', '$code2', '$date2')";
    $sql = mysqli_query($connect, $add);
echo '<meta http-equiv="refresh" content="0;url=wageslips.php?action=added">';
}
?></center>                               
                  </div>
              </div>
            </div>
        </div>
      </div>

 
    </div>
  </div>
  

<?php
include "footer.php";
?>