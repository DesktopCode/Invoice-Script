<?php
include "header.php";

if (isset($_GET['delete-id'])) {
    $id    = (int) $_GET["delete-id"];
    $query = mysqli_query($connect, "DELETE FROM `posts` WHERE id='$id'");
    $delmsg = "Invoice Deleted.";
}

if (isset($_GET['pid'])) {
    $id    = (int) $_GET["pid"];
    $query = mysqli_query($connect, "update posts SET views='0' WHERE id='$id'");
    $delmsg = "Invoice Moved to Unpaid.";
}
?>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
        </ol>
      </div>
	  
	  <div class="row">
        <div class="col-md-9 column" style="margin-left:300px;">
            <div class="box">
              <h4 class="box-header round-top">Invoices</h4>
              <div class="box-container-toggle">
                  <div class="box-content">
				  <center><a href="wageslips.php" class="btn btn-success">Invoices</a></center><br />
 <?php if($delmsg){ ?>
<div class="alert alert-success" role="alert">
<strong> <?php echo htmlentities($delmsg);?></strong></div>
<?php } ?>
 <?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong> <?php echo htmlentities($msg);?></strong></div>
<?php } ?>
         <div class="search-bar">
                                          <div id="imaginary_container">
                                          <div class="input-group stylish-input-group">
                                          <form action="searchslips.php" method="post">
                                          <span class="input-group-addon">
                                          <input type="text"   name="search" placeholder="Search Employee ID">
                                          <button type="submit" name"button0" class="button0" style="margin-left:-20px;"><font size="4"><i class="fa fa-search" aria-hidden="true" style="padding:2px;"></i></font></button>
                                          </form>
                                        </span>
                                       </div>
                                    </div>
                                 </div>
<?php
     if (isset($_GET['pagenum'])) {
            $pageno = $_GET['pagenum'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 10;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM posts";
        $result2 = mysqli_query($connect,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result2)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

$sql   = "SELECT * FROM posts ORDER by id DESC LIMIT $offset, $no_of_records_per_page";
$result = mysqli_query($connect, $sql);
$count  = mysqli_num_rows($result);
if ($count <= 0) {
    echo 'There are no invoices.';
} else {
?>
            <table class="table table-bordered table-striped table-hover" id="dt-basic">
                <thead>
				<tr>
				    <th>ID</th>
                    <th>Amount</th>

<th>Date</th>
                    <th>Link</th>
					<th>Employee</th> 
                                <th>NI Number</th>
					<th>Actions</th>
                </tr>
				</thead>
<?
     if (isset($_GET['pagenum'])) {
            $pageno = $_GET['pagenum'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM posts";
        $result2 = mysqli_query($connect,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result2)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

$sql   = "SELECT * FROM posts ORDER by id DESC";
       while($row = mysqli_fetch_assoc($result))  {
        $category_id = $row['category_id'];
        $runq2       = mysqli_query($connect, "SELECT * FROM `categories` WHERE id='$category_id'");
        $cat         = mysqli_fetch_assoc($runq2);
?>
                <tr>
<?php if ($row['views'] == '1') { 
    $sqlc = mysqli_query($connect, "SELECT email FROM `settings` WHERE id = '1'");
    $rowc = mysqli_fetch_assoc($sqlc);
?>
				    <td><?php echo $row['id']; ?></td>
	                <td><?php echo $rowc['email'];?><?php echo $row['title']; ?></center></td>
<td><?php echo $row['date'];?></td>
	                <td><a href="<?php echo $site_url;?>/wageslips.php?id=<?php echo $row['id'];?>" target=_blank class="btn btn-success">View Wage Slip</a></td>

                    <td><?php echo $cat['category'];?></td>
 <td><?php echo $cat['ninumber'];?></td>

		<td>
					   
						<a href="/wage/admin/paidslips.php?pid=<?php echo $row['id'];?>" class="btn btn-success">PAID</a>
					
					   
						<a href="?delete-id=<?php echo $row['id'];?>" title="Delete" class="btn btn-danger"><i class="fa fa-remove"></i> Delete</a>
					</td>
                </tr>
<?php } } }?>
            </table>
</center>
<?php 
$prevpage = $pageno - 1;
$nextpage = $pageno + 1;
?>
<center>
<div class="pagebtn">
          <ul class="pagination justify-content-center">
          <li class="page-item"><a href="?pagenum=1"  class="page-link">First</a></li>
          <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pagenum=".($pageno - 1); } ?>" class="page-link"><?php echo $prevpage;?></a>
          </li>
          <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pagenum=".($pageno + 1); } ?>" class="page-link" style="padding-left:5pxpadding-right:5px;;"><?php echo $pageno;?></a>
          </li>
          <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pagenum=".($pageno + 1); } ?>" class="page-link"><?php echo $nextpage;?></a>
          </li>
          <li class="page-item"><a href="?pagenum=<?php echo $total_pages; ?>" class="page-link">Last</a></li>
          </ul>
</div>		
</center>
                  </div>
              </div>
            </div>
        </div>
      </div>
 
<?php
if (isset($_GET['edit-id'])) {
    $id  = (int) $_GET["edit-id"];
    $sql = mysqli_query($connect, "SELECT * FROM `posts` WHERE id = '$id'");
    $row = mysqli_fetch_assoc($sql);
    if (empty($id)) {
        echo '<meta http-equiv="refresh" content="0; url=wageslips.php">';
    }
    if (mysqli_num_rows($sql) == 0) {
        echo '<meta http-equiv="refresh" content="0; url=wageslips.php">';
    }
?>
    <div class="row">
        <div class="col-md-18 column">
            <div class="box">

              <div class="box-container-toggle">
                  <div class="box-content">
<center><form action="" method="post">
								<p>
									<label>Title</label>
									<input class="form-control" class="form-control" name="title" type="text" value="<?php
    echo $row['title'];
?>" required>
								</p><br />
								<p>
									<label>% Off</label><br />
									<input class="form-control" class="form-control" name="title2" type="text" value="<?php
    echo $row['title2'];
?>" required>
								</p><br />
		<p>
									<label>Expiration Date</label><br />
									<input class="form-control" class="form-control" name="date" type="text" value="<?php
    echo $row['date'];
?>" required>
								</p><br />
								<p>
									<label>Active
                                    </label><br />
									<select name="active" class="form-control" required>
									    <option value="Yes" <?php
    if ($row['active'] == "Yes") {
        echo 'selected';
    } else {
        echo '';
    }
?>>Yes</option>
									    <option value="No" <?php
    if ($row['active'] == "No") {
        echo 'selected';
    } else {
        echo '';
    }
?>>No</option>
                                    </select>
								</p><br />
								<p>
									<label>Category</label><br />
									<select name="category_id" class="form-control" required>
									<?php
    $crun = mysqli_query($connect, "SELECT * FROM `categories` WHERE id='$category_id' LIMIT 1");
    while ($cat = mysqli_fetch_assoc($crun)) {
        echo '
                                    <option value="' . $cat['id'] . '" selected>' . $cat['category'] . '</option>
									';
    }
?>
									<?php
    $crun = mysqli_query($connect, "SELECT * FROM `categories`");
    while ($rw = mysqli_fetch_assoc($crun)) {
        echo '
                                    <option value="' . $rw['id'] . '">' . $rw['category'] . '</option>
									';
    }
?>
                                    </select>
								</p><br />
								<p>
									<label>Content</label>
									<textarea name="content" rows="6" required><?php
    echo html_entity_decode($row['content']);
?></textarea>
								</p>
<div class="form-actions">
    <input type="submit" class="btn btn-primary" name="submit" value="Save" /><br />
</div>
</form>
<?php
    if (isset($_POST['submit'])) {
        $title       = addslashes($_POST['title']);
        $title2       = addslashes($_POST['title2']);
$date       = addslashes($_POST['date']);
        $active      = addslashes($_POST['active']);
        $category_id = addslashes($_POST['category_id']);
        $content     = htmlspecialchars($_POST['content']);
        
        $edit = "UPDATE posts SET title='$title', '$title2'', date='$date', active='$active', category_id='$category_id', content='$content' WHERE id='$id'";
        $sql  = mysqli_query($connect, $edit);
        echo '<meta http-equiv="refresh" content="0;url=wageslips.php">';
    }
?></center>



                                </body>
                            </html>







                  </div>
              </div>
            </div>
        </div>
     </div>
<?php
}
?>
    </div>
  </div>

<script>
$(document).ready(function() {

	$('#dt-basic').dataTable( {
		"responsive": true,
		"language": {
			"paginate": {
			  "previous": '<i class="fa fa-angle-left"></i>',
			  "next": '<i class="fa fa-angle-right"></i>'
			}
		}
	} );
} );
</script>
<script>
    CKEDITOR.replace( 'content' );
</script>
<script>
function CopyToClipboard(id)
{
var r = document.createRange();
r.selectNode(document.getElementById(id));
window.getSelection().removeAllRanges();
window.getSelection().addRange(r);
document.execCommand('copy');
window.getSelection().removeAllRanges();
}
</script>
<?php
include "footer.php";
?>