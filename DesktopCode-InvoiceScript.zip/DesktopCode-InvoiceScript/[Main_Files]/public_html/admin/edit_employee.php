<?php
include "header.php";
?>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
        </ol>
      </div>  

      <div class="row">
<?php
$id    = intval($_GET['edit-id']);
$editem = mysqli_query($connect, "SELECT * from categories where id='$id'");
$sqledit = mysqli_fetch_assoc($editem);
?>


         <div class="col-md-9 column" style="margin-left:300px;">
         <div class="box">
         <h4 class="box-header round-top">Edit Employee</h4>         
              <div class="box-container-toggle">
                  <div class="box-content">
                                <center><form action="" method="post">
								<p>
									<label>Name</label>
									<input class="form-control" name="category" value="<?php echo $sqledit['category'];?>" type="text" style="width:25%;" required>
								</p>
<p>
									<label>National Insurance Number</label>
									<input class="form-control" name="ninumber" value="<?php echo $sqledit['ninumber'];?>" type="text" style="width:25%;" required>
								</p>
								<div class="form-actions">
                                    <input type="submit" name="add" class="btn btn-primary" value="Update" />
								
                                </div>
								</form>

<?php
if (isset($_POST['add'])) {
    $category = $_POST['category'];
 $ninumber = $_POST['ninumber'];
    
    $add = "UPDATE categories SET category='$category', ninumber='$ninumber' where id='$id'";
    $sql = mysqli_query($connect, $add);
    echo '<meta http-equiv="refresh" content="0; url=employees.php?action=updated">';
}
?></center>                               
                  </div>
              </div>
            </div>
        </div>
      </div>

 
    </div>
  </div>

<?php
include "footer.php";
?>