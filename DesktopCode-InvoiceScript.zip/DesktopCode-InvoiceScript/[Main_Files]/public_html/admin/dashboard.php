<?php
include "header.php";
session_start();
    $uname = $_SESSION['sec-username'];
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Exo+2:wght@500&display=swap');
</style>
<style>
@import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree&display=swap');
</style>
<style>
@import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@500&display=swap');
</style>
<style>
html *
{
font-family: 'Bai Jamjuree;
font-size: 14px;
}

.copyright { margin-top: 50px; font-size: 12px; text-transform: uppercase; }
.copyright a { text-decoration: none; padding: 5px;background: #c0392b; color: #000; }
.copyright a:hover { background: transparent; color: #c0392b; }

.copyright *
{
font-family: 'Exo 2'; !important;
text-transform: uppercase; 
font-size: 12px;
}
</style>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
        </ol>
      </div>

	  <div class="row">
        <div class="col-md-12 column">
            <div class="box">
  
              <div class="box-container-toggle">
                  <div class="box-content">
				  <ul class="shortcut-list">
							
<h2><center><br>Invoice Admin Panel</h2>

						</ul><br><br>
<center><font size="4">User Online: <b><?php echo $uname;?></b></font> <br><a href="logout.php" class="btn btn-primary">Logout</a></center>
				  </div>
              </div>
            </div>
        </div>
      </div>
	  
	  <div class="row">

         
              </div>
            </div>
         </div>
      </div>
 
    </div>
  </div>

<?php
include "footer.php";
?>