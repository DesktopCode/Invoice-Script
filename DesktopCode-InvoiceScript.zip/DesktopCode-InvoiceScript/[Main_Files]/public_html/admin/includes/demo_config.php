<?php
$host     = "localhost"; // Database Host
$user     = "root"; // Database Username
$password = "password"; // Database's user Password
$database = "database"; // Database Name

$connect = new mysqli($host, $user, $password, $database);

$site_url       = "https://www.desktopcode.com";

// Checking Connection
if (mysqli_connect_errno()) {
    printf("Database connection failed: %s\n", mysqli_connect_error());
    exit();
}

mysqli_set_charset($connect, "utf8");

?>