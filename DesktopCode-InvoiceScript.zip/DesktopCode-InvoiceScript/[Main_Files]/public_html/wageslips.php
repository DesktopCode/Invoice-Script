<?php
session_start();
include 'admin/includes/config.php';
$id = (int) $_GET['id'];
if (empty($id)) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}

$runq = mysqli_query($connect, "SELECT * FROM `posts` WHERE id='$id'");
if (mysqli_num_rows($runq) == 0) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}
$row         = mysqli_fetch_assoc($runq);
$employeeid =$row['category_id'];
$employee = mysqli_query($connect, "SELECT * FROM `categories` WHERE id='$employeeid'");
$row2  = mysqli_fetch_assoc($employee);
$invoicedetail = mysqli_query($connect, "SELECT * FROM `posts` WHERE id='$id'");
$invoicedetails  = mysqli_fetch_assoc($invoicedetail);

$settings1 = mysqli_query($connect, "SELECT * FROM `settings` WHERE id='1'");
$row3  = mysqli_fetch_assoc($settings1);
$freeallow = $invoicedetails['content2'];
$itpercentage1 = $invoicedetails['title2'];
$grossamount1 = $invoicedetails['title'] - $freeallow;
$netamount1 = ($itpercentage1 / 100) * $grossamount1;
$itpercentage2 = $invoicedetails['content'];
$grossamount2 = $invoicedetails['title'] - $freeallow;
$netamount2 = ($itpercentage2 / 100) * $grossamount2;
$netam = ($netamount1 + $netamount2);
$netamount = ($invoicedetails['title'] - $netam);

    $sqlc = mysqli_query($connect, "SELECT email FROM `settings` WHERE id = '1'");
    $rowc = mysqli_fetch_assoc($sqlc);
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title><?php echo $row3['sitename'];?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./wagecss.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div id="payslip">
	<div id="title"><img src="images/<?php echo $row3['headerimg'];?>" width="100%" height="100%"></div>
	<div id="scope">
		<div class="scope-entry">
			<div class="title">Date</div>
			<div class="value"><?php echo $row['date'];?></div>
		</div>
		<div class="scope-entry">
			<div class="title">Employee</div>
			<div class="value"><?php echo $row2['category'];?></div>
		</div>

<div class="scope-entry">
			<div class="title">National Insurance</div>
			<div class="value"><?php echo $row2['ninumber'];?></div>
		</div>
	</div>
	<div class="content">
		
		<div class="right-panel">
			<div class="details">
				
				<div class="nti">
					<div class="entry">
						<div class="label"><font color="black">GROSS AMOUNT</font></div>
						<div class="detail"></div>
						<div class="rate"></div>
						<div class="amount"><font color="black"><?php echo $rowc['email'];?><?php echo $row['title'];?></font></div>
					</div>
				</div>
				<div class="withholding_tax">
					<div class="entry">
						<div class="label"><font color="black">National Insurance</font></div>
						<div class="detail"></div>
						<div class="rate"><font color="black"></font></div>
<div class="rate"><font color="black"></font></div>
						<div class="amount"><font color="black">- <?php echo $rowc['email'];?><?php echo $netamount1;?></font></div>
					</div>
				</div>
				<div class="non_taxable_allowance">
					<div class="entry">
						<div class="label"><font color="black">Income Tax</font></div>
						<div class="detail"></div>
						<div class="rate"><font color="black"></font></div>
<div class="rate"><font color="black"></font></div>
						<div class="amount"><font color="black">- <?php echo $rowc['email'];?><?php echo $netamount2;?></font></div>
					</div>
					
				</div>
				
				<div class="net_pay">
					<div class="entry">
						<div class="label"><font color="black">NET AMOUNT</font></div>
						<div class="detail"></div>
						<div class="rate"></div>
						<div class="amount"><font color="black"><?php echo $rowc['email'];?><?php echo $netamount;?></font></div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<!-- partial -->
  
</body>
</html>
